//
//  ViewController.m
//  segmentcontroller
//
//  Created by Yogesh Patel on 03/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize segout,img;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)segact:(id)sender
{
    switch (self.segout.selectedSegmentIndex)
    {
        case 0:
            self.img.image=[UIImage imageNamed:@"twitter.png"];
            break;
        case 1:
            self.img.image=[UIImage imageNamed:@"facebook.png"];
            break;
        case 2:
            self.img.image=[UIImage imageNamed:@"linkedin.jpg"];
            break;
        case 3:
            self.img.image=[UIImage imageNamed:@"google.jpg"];
            break;
            
        default:
            break;
    }
}
@end
