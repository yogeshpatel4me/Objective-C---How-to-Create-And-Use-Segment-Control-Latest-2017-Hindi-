//
//  ViewController.h
//  segmentcontroller
//
//  Created by Yogesh Patel on 03/08/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segout;
- (IBAction)segact:(id)sender;

@end

